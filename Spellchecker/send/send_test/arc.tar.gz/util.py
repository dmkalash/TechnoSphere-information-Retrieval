def d():
	return 1 + 2
